﻿# G1 suite re-run - 20261012T105559594Z-82235771-win32-x64

**Status: FAIL**

Scope: re-run of the frozen G1 library suite only. **Gates G1a and G1b remain NOT passed.**

Environment: see env.json (node/npm/os; conformance to baseline Node 22).

| Check | OK | Detail |
|---|---|---|
| frozen-before | False | 18 files; differences vs SHA256SUMS: 2 |
| exception | False | Frozen suite does not match its manifest. |
| frozen-finally | False | Checked even after failure or blocked run. |
