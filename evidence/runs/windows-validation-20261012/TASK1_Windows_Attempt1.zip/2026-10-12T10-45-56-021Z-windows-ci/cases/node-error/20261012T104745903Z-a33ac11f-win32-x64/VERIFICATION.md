﻿# G1 suite re-run - 20261012T104745903Z-a33ac11f-win32-x64

**Status: FAIL**

Scope: re-run of the frozen G1 library suite only. **Gates G1a and G1b remain NOT passed.**

Environment: see env.json (node/npm/os; conformance to baseline Node 22).

| Check | OK | Detail |
|---|---|---|
| frozen-before | True | 18 files; differences vs SHA256SUMS: 0 |
| lock-before-ci | True | d3af25764d221d4bdca94dc49335deca8514a21e20d0611515aa297828fbe524 |
| npm-ci-exit | True | exit=0 |
| lock-after-ci | True | d3af25764d221d4bdca94dc49335deca8514a21e20d0611515aa297828fbe524 |
| main-process-exit | False | exit=19 |
| main-strict-json | True | validator exit=0 |
| main-results | True | run.mjs exit=19 (not used for the verdict) |
| mutation_skip-chain-process-exit | False | exit=19 |
| mutation_skip-chain-strict-json | True | validator exit=0 |
| mutation_skip-chain-results | True | run.mjs exit=19 (not used for the verdict) |
| mutation_skip-role-process-exit | False | exit=19 |
| mutation_skip-role-strict-json | True | validator exit=0 |
| mutation_skip-role-results | True | run.mjs exit=19 (not used for the verdict) |
| main-total | True | 62/62 |
| main-reasons | True | rejections without matching reason:  |
| main-lock-in-results | True | d3af25764d221d4bdca94dc49335deca8514a21e20d0611515aa297828fbe524 |
| main-equals-original-report | True | same ids, observed outcomes and pass flags as the original evidence |
| skip-chain-detected | True | 56/62; failed: REV-05,REV-08,SIG-05,SIG-06,VER-12,X-17 |
| skip-role-detected | True | 60/62; failed: REV-05,VER-12 |
| frozen-after | True | 18 files; differences vs SHA256SUMS: 0 |
| frozen-git-clean | True | git status --porcelain on the frozen folder |
| frozen-finally | True | Checked even after failure or blocked run. |
