﻿# G1 suite re-run - 20261012T104727297Z-db9ce106-win32-x64

**Status: FAIL**

Scope: re-run of the frozen G1 library suite only. **Gates G1a and G1b remain NOT passed.**

Environment: see env.json (node/npm/os; conformance to baseline Node 22).

| Check | OK | Detail |
|---|---|---|
| frozen-before | True | 18 files; differences vs SHA256SUMS: 0 |
| lock-before-ci | True | d3af25764d221d4bdca94dc49335deca8514a21e20d0611515aa297828fbe524 |
| npm-ci-exit | True | exit=0 |
| lock-after-ci | True | d3af25764d221d4bdca94dc49335deca8514a21e20d0611515aa297828fbe524 |
| main-process-exit | True | exit=0 |
| main-strict-json | False | validator exit=1 |
| exception | False | Invalid object passed in, ':' or '}' expected. (11): { invalid JSON
 |
| frozen-finally | True | Checked even after failure or blocked run. |
